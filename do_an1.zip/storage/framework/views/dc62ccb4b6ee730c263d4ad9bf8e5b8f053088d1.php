

<?php $__env->startSection('title', 'Review detail'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/detail.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="containerInner detailHead">
            <div class="container detailTitle d-flex">
                <div class="inf-1">
                    <?php if($product->img_url): ?>
                        <img src="<?php echo e($product->img_url); ?>" alt="">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/images/default_image.png')); ?>" alt="">
                    <?php endif; ?>
                </div>
                <div class="inf-2">
                    <h1><?php echo e($product->name); ?></h1>
                    <span style="font-weight: 500;">
                        <i style="color:#879596;">By:</i>
                        <span style="color: blue;">
                            <?php echo e($product->vendor->name); ?>

                        </span>
                    </span>
                    <div class="inf-category"><?php echo e($product->category->name); ?></div>
                    <div class="inf-review d-flex">
                        <?php echo $__env->make('components.helper.star', ['count_star' => 5, 'class_star' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <span style="margin: 0px 1.5rem; padding: 2px; color: blue; font-weight: 600;">
                            10 reviews
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <?php if(session('alert')): ?>  
        <div class="alert alert-success" role="alert">  
            <?php echo e(session('alert')); ?>

        </div>  
        <?php endif; ?>
        <?php if(session('error')): ?>   
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
        <?php $__currentLoopData = $product->criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/prod_detail/detail_review.blade.php ENDPATH**/ ?>
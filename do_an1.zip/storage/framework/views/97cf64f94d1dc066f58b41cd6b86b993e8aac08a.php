<?php if(session('alert')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('alert')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/layout/alert.blade.php ENDPATH**/ ?>
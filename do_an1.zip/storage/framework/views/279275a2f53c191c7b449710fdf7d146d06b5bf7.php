<span class="<?php echo e($class_star); ?>" style="fill: #eb5f07;">
    <?php for($i = 0; $i < $count_star; $i++): ?>
        <svg version="1.1" viewBox="0 0 19 18" height="14" width="14" data-test-selector-star-type="STAR_FULL">
            <g>
                <polygon class="fullStar--2qrjU7vzpY star--3RwBtJvIXw"
                    points="9.5 0 6.564 5.926 0 6.875 4.75 11.488 3.628 18 9.5 14.926 15.371 18 14.249 11.488 18.999 6.875 12.435 5.926">
                </polygon>
            </g>
        </svg>
    <?php endfor; ?>
</span>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/helper/star.blade.php ENDPATH**/ ?>
<div class="mt-3 ms-3">
    <div class="row">
        <h3 class="view-title col-10">Suggestion Service</h3>
        <a href="<?php echo e(route('myProject.createNote', ['id' => $project->id ])); ?>" class="col-2">
            <button type="button" class="btn btn-outline-primary">
                <i class="bi bi-plus-lg me-2"></i>Add requirements
            </button>
        </a>
    </div>
    <div class="row mb-2 mt-4">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                    <div class="col-auto d-none d-lg-block">
                        <?php if($product->img_url): ?>
                            <img src=<?php echo e(asset($product->img_url)); ?> alt="" >
                        <?php else: ?>
                            <img src=<?php echo e(asset('assets/images/default_image.png')); ?> alt="" style="width: 200px; height: 209px;">
                        <?php endif; ?>
                    </div>
                    <div class="col p-4 d-flex flex-column position-static">
                        <h4 class="name-product"><?php echo e($product->name); ?></h4>
                        <strong class="d-inline-block mb-2 text-primary">By: <?php echo e($product->vendor->name); ?></strong>
                        <div class="mb-1 text-muted">
                            <?php echo $__env->make('components.helper.star', ['count_star' => round($product->ratings_avg_number_star), 'class_star' => 'col-5'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('components.helper.star', ['count_star' => (5 - round($product->ratings_avg_number_star)), 'class_star' => 'col-5 white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <a href="<?php echo e(route('show', ['id' => $product->id, 'type' => 'reviews'])); ?>" class="shared-item_cards-author_category_component__link">
                                <span style="padding: 2px; color: blue; font-weight: 600;">
                                    <?php echo e($product->commnets->count()); ?> reviews
                                </span>
                            </a>
                        </div>
                        <p class="card-text mb-auto"><?php echo e($product->description); ?></p>
                        <a href="<?php echo e(route('show', ['id' => $product->id])); ?>" class="stretched-link">Continue reading</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h3 class="view-title mt-5">Project information</h3> 
    <?php $__currentLoopData = $project->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-4 d-flex parent-all-inf">
            <div class="all-inf">
                <div class="d-flex align-items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="green" class="bi bi-check2" viewBox="0 0 16 16">
                        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                    </svg>
                    <p class="fs-5 ms-2"><?php echo e($note->note); ?></p>
                </div>
                <ul class="list-inf ms-5">
                    <?php $__currentLoopData = $note->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <p class="ms-3" style="font-size: 18px;"><?php echo e($question->question); ?></p>
                        </li>
                        <?php $__currentLoopData = $question->criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="ms-5">
                            <p class="ms-3" style="font-size: 18px;">Desired Criteria: <?php echo e($criteria->name); ?></p>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="edit-update-inf">
                <a href="<?php echo e(route('myProject.editNote', ['project_id' => $project->id, 'note_id' => $note->id])); ?>" class="me-1"><i class="bi bi-pencil-square fs-5"></i></a>
                <a class="text-danger me-2" data-bs-toggle="modal" data-bs-target="<?php echo e('#deleteModal' . $note->id); ?>"><i class="bi bi-trash3-fill fs-5"></i></a>
            </div>
            <?php echo $__env->make('components.modal.modal_delete', ['project' => $project, 'note' => $note, 'id' => $note->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/project_criteria/show_infor.blade.php ENDPATH**/ ?>
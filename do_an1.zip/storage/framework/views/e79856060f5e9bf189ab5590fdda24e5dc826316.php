

<?php $__env->startSection('title', 'Cloud Services'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/home.css')); ?>">

<?php $__env->startSection('content'); ?>
    <main>
        <?php echo $__env->make('components.home.head_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <div class="input-group position-relative">
                <input type="text" id="search-input" value="" class="form-control rounded" placeholder="Search" />
                <i class="bi bi-x clearIcon d-none"></i>
                <button id="search-button" class="btn btn-outline-primary">search</button>
            </div>
            <div class="search-index_content__searchResults mt-5">
                <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/home.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title','test'); ?>

<?php echo $__env->make('menu', ['test' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <p>This is my body content.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/test.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Cloud Services'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/my_project.css')); ?>">

<?php $__env->startSection('content'); ?>
    <main>
        <div class="container mt-5">
            <div class="flex-grow-1 d-flex flex-column">
                <ul class="bread-crumb mb-3">
                    <li>
                        <a _ngcontent-lnm-c460="" data-testid="breadcrumb-0">
                            <span _ngcontent-lnm-c460="">My Projects</span>
                        </a>
                    </li>
                </ul>
                <form action="" class="input-group ms-3" method="GET">
                    <input type="text" name="q" value="<?php echo e(app('request')->input('q') ?? ''); ?>" class="form-control rounded" placeholder="Search" />
                    <button type="submit" class="btn btn-outline-primary">search</button>
                </form>
                <div class="flex-grow-1 p-3 min-height-0">
                    <div class="flexbox solution h-100">
                        <div class="flexbox-scroll">
                            <?php echo $__env->make('components.my_project.project', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/my_project.blade.php ENDPATH**/ ?>
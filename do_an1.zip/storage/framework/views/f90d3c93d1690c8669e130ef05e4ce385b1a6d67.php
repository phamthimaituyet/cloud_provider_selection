<div class="row">
    <div class="col-lg-3 col-md-4 col-sm-6" data-bs-toggle="modal" data-bs-target="#myProject">
        <div class="businessContainer center-button">
            <i class="bi bi-plus-lg icon icon-plus-b24"></i>
            <span class="text fw-bold">
                <span>Project</span>
            </span>
        </div>
    </div>
    <?php $__currentLoopData = $myProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="businessContainer center-button">
                <div class="mt-3" style="float: right;">
                    <a class="me-1" data-bs-toggle="modal" data-bs-target="<?php echo e('#editMyProject' . $myProject->id); ?>"><i class="bi bi-pencil-square fs-5"></i></a>
                    <a class="text-danger me-2" data-bs-toggle="modal" data-bs-target="<?php echo e('#deleteModal' . $myProject->id); ?>"><i class="bi bi-trash3-fill fs-5"></i></a>
                </div>
                <a href="<?php echo e(route('myProject.showProduct', ['id' => $myProject->id])); ?>" class="text-dark" style="text-decoration: none;">
                    <div class="d-flex align-items-end">
                        <img class="d-block mt-2 ms-3" src="<?php echo e(asset('assets/images/project2.svg')); ?>">
                        <p class="ms-3 fw-bold"><?php echo e($myProject->name); ?></p>
                    </div>
                    <div class="mt-5 ms-3">
                        <p>Last change</p>
                        <p class="col-8"><?php echo e($myProject->created_at->format('d.m.Y')); ?></p>
                    </div>
                </a>
            </div>
        </div>
        <?php echo $__env->make('components.modal.modal_delete', ['id' => $myProject->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.modal.modal_editMyProject', ['id' => $myProject->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('components.modal.modal_myProject', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/my_project/project.blade.php ENDPATH**/ ?>
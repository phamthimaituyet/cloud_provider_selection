<div class="containerInner detailHead">
    <div class="container detailTitle d-flex">
        <div class="inf-1">
            <?php if($product->img_url): ?>
                <img src="<?php echo e(url($product->img_url)); ?>" alt="">
            <?php else: ?>
                <img src="<?php echo e(asset('assets/images/default_image.png')); ?>" alt="">
            <?php endif; ?>
        </div>
        <div class="inf-2 flex-grow-1">
            <h1><?php echo e($product->name); ?></h1>
            <span style="font-weight: 500; font-size: 17px;">
                <i style="color:#879596;">By:</i>
                <span style="color: blue;">
                    <?php echo e($product->vendor->name); ?>

                </span>
            </span>
            <div class="inf-category"><?php echo e($product->category->name); ?></div>
            <div class="inf-review d-flex">
                <div>
                    <?php echo $__env->make('components.helper.star', ['count_star' => round($rating_avg), 'class_star' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('components.helper.star', ['count_star' => (5 - round($rating_avg)), 'class_star' => 'col-5 white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <span style="margin: 0px 1.5rem; padding: 2px; color: blue; font-weight: 600;">
                    <?php echo e($review_stars->count()); ?> reviews
                </span>
            </div>
        </div>
        <div class="inf-3 d-flex" style="place-items: flex-end;">
        <?php if(Auth::check()): ?>
                <div class="px-4 mt-2 mb-2">
                    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#reviewModal">
                        <i class="bi bi-chat-left-text"></i> Write a review
                    </button>
                    <a href="<?php echo e(route('detailReview', ['id' => $product->id])); ?>">
                        <button type="button" class="btn btn-outline-info">
                            <i class="bi bi-chevron-double-right"></i> Detailed review
                        </button>
                    </a>
                </div>
            <?php else: ?> 
                <a href="<?php echo e(route('login.form')); ?>">
                    <div class="px-4 mt-2 mb-2">
                        <button type="button" class="btn btn-outline-secondary">
                            <i class="bi bi-chat-left-text"></i> Write a review
                        </button>
                        <button type="button" class="btn btn-outline-info">
                            <i class="bi bi-chevron-double-right"></i> Detailed review
                        </button>
                    </div>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/prod_detail/prod_head.blade.php ENDPATH**/ ?>
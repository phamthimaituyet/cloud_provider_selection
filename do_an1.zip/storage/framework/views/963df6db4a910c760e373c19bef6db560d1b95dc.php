<link rel="icon" href="https://cdn-icons-png.flaticon.com/512/7794/7794360.png" type="image/x-icon">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/plugins/fontawesome-free/css/all.min.css')); ?>">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<!-- Tempusdominus Bbootstrap 4 -->
<link rel="stylesheet"
    href="<?php echo e(asset('vendors/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
<!-- iCheck -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<!-- JQVMap -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/plugins/jqvmap/jqvmap.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/dist/css/adminlte.css')); ?>">
<!-- overlayScrollbars -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
<!-- Daterange picker -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/plugins/daterangepicker/daterangepicker.css')); ?>">
<!-- summernote -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/plugins/summernote/summernote-bs4.css')); ?>">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/my_app.css')); ?>">
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/layouts/head_index.blade.php ENDPATH**/ ?>
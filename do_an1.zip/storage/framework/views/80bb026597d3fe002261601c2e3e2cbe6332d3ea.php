<div class="mt-4 text-end">
    <div>
        <button type="button" class="btn btn-outline-primary">
            <i class="bi bi-plus-lg me-2"></i>Add note
        </button>
    </div>
</div>


<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/project_criteria/add_criteria.blade.php ENDPATH**/ ?>
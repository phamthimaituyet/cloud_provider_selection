
<?php echo $__env->make('admin.layouts.link_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Service selection support'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/detail.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/support.css')); ?>">

<?php $__env->startSection('content'); ?>
    <main>
        <?php echo $__env->make('components.home.head_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container mt-5">
            <h1 class="fst-italic mb-3">Top 5 cloud products of the right provider</h1>
            <div class="d-flex mt-5">
                <div class="me-5" style="width: 80%;">
                    <div class="top_product mb-5">
                        <img src="<?php echo e(asset('assets/images/Cloud-computing-service-providers_Startuptalky.jpg')); ?>" alt="">
                        <p>Top cloud products of the right provider</p>
                    </div>
                    <div>
                        <p class="mb-3 fs-4">The system gives the top 5 suitable services that are calculated and analyzed based on user-supplied data.</p>
                    </div>
                    <?php echo $__env->make('components.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <div class="tag_criteria" method="GET" action="">
                        <h5 class="fst-italic mb-3 text-danger tag_criteria_title">
                            Outstanding experience
                        </h5>
                        <ul class="nav nav-pills nav-sidebar flex-column container" data-widget="treeview" role="menu" data-accordion="false">
                            <li class="nav-item" style="font-size: 20px;">
                                <a href="<?php echo e(route('myProject.show')); ?>">Suggest services tailored to each project requirement</a>
                            </li>
                            <li class="nav-item mt-5" style="font-size: 20px;">
                                <a href="<?php echo e(route('home')); ?>">Information about cloud services of providers</a>
                            </li>
                            <li class="nav-item mt-5" style="font-size: 20px;">
                                <a href="<?php echo e(route('myProject.show')); ?>">Suggest services tailored to each project requirement</a>
                            </li>
                            <li class="nav-item mt-5" style="font-size: 20px;">
                                <a href="<?php echo e(route('myProject.show')); ?>">Suggest services tailored to each project requirement</a>
                            </li>
                            <li class="nav-item mt-5" style="font-size: 20px;">
                                <a href="<?php echo e(route('myProject.show')); ?>">Suggest services tailored to each project requirement</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/support_select.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title','Product'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Products</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Products</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="content">

        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title" style="color: red; 
                                        font-size: 20px;
                                        font-weight: 700;"><?php echo e($product->name); ?></h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                        <i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                        <i class="fas fa-times"></i></button>
                </div>
            </div>
            <div class="card-body">

                <div>
                    <div class="row">
                        <div class="col-12">
                            <div class="post">
                                <h3 style="color: #0D6EFD;">Description</h3>
                                <p><?php echo e($product->description); ?></p>
                            </div>

                            <div class="post clearfix">
                                <h3 style="color: #0D6EFD;">Support</h3>
                                <p><?php echo e($product->support); ?></p>
                            </div>

                            <div class="post">
                                <h3 style="color: #0D6EFD;">Pricing</h3>
                                <div class="card">
                                    <div class="card-body p-0">
                                        <table class="table">
                                            <thead style="background-color: #DBDBDB;">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Type price</th>
                                                    <th>Date use (date)</th>
                                                    <th>Price (USD)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $product->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                    <td>#</td>
                                                    <td><?php echo e($price->type); ?></td>
                                                    <td><?php echo e($price->date_use); ?></td>
                                                    <td><?php echo e($price->price); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                            </div>

                            <div class="post">
                                <h3 style="color: #0D6EFD;">Criteria</h3>
                                <div class="card">
                                    <div class="card-body p-0">
                                        <table class="table">
                                            <thead style="background-color: #DBDBDB;">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name criteria</th>
                                                    <th>Name Factor</th>                                         
                                                    <th>Value</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $product->criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                    <td>#</td>
                                                    <td><?php echo e($criteria->name); ?></td>
                                                    <td><?php echo e($criteria->getNameRootParent($criteria->parent_id)); ?></td>                                                
                                                    <td><?php echo e($criteria->pivot->value); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', ['product' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/pages/product/show.blade.php ENDPATH**/ ?>
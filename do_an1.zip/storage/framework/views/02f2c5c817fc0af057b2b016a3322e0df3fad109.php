<?php $array = [$users->count(), $products->count(), $categories->count(), $criterias->count()] ?>



<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php if(session('thongbao')): ?>
<div style=" color: green;
            font-size: 18px;
            padding: 15px;">
    <i class="fa fa-check" aria-hidden="true"></i> <b><?php echo e(session('thongbao')); ?></b>
</div>
<?php endif; ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Dashboard</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-body">
    <table class="table table-condensed table-striped table-hover">
        <thead>
            <tr>
                <th class="shrink model-name" style=" width: 25%;">
                    Model name
                </th>
                <th class="shrink last-created" style=" width: 20%;">
                    Last created
                </th>
                <th class="records" style=" width: 40%;">
                    Records
                </th>
            </tr>
        </thead>
        <tbody>
            <tr class="odd link active_storage_attachment_links">
                <td>
                    <span class="show">
                        <a href="<?php echo e(route('user')); ?>">User</a>
                    </span>
                </td>
                <td>
                    <?php echo e($users->first()->created_at); ?>

                </td>
                <td>
                    <div class="progress" style="margin-bottom:0px">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-success"
                            role="progressbar" style="width: <?= getPercent($users->count(), $array) ?>%">
                            <?php echo e($users->count()); ?>

                        </div>
                    </div>
                </td>
            </tr>
            <tr class="odd link active_storage_attachment_links">
                <td>
                    <span class="show">
                        <a href="<?php echo e(route('category')); ?>">Category</a>
                    </span>
                </td>
                <td>
                    <?php echo e($categories->first()->created_at); ?>

                </td>
                <td>
                    <div class="progress" style="margin-bottom:0px">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning"
                            role="progressbar" style="width: <?= getPercent($categories->count(), $array) ?>%">
                            <?php echo e($categories->count()); ?>

                        </div>
                    </div>
                </td>

            </tr>
            <tr class="odd link active_storage_attachment_links">
                <td>
                    <span class="show">
                        <a href="<?php echo e(route('product')); ?>">Products</a>
                    </span>
                </td>
                <td>
                    <?php echo e($products->first()->created_at); ?>

                </td>
                <td>
                    <div class="progress" style="margin-bottom:0px">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
                            style="width: <?= getPercent($products->count(), $array) ?>%">
                            <?php echo e($products->count()); ?>

                        </div>
                    </div>
                </td>

            </tr>
            <tr class="odd link active_storage_attachment_links">
                <td>
                    <span class="show">
                        <a href="<?php echo e(route('criteria')); ?>">Criterias</a>
                    </span>
                </td>
                <td>
                    <?php echo e($products->first()->created_at); ?>

                </td>
                <td>
                    <div class="progress" style="margin-bottom:0px">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-danger" role="progressbar"
                            style="width: <?= getPercent($criterias->count(), $array) ?>%">
                            <?php echo e($criterias->count()); ?>

                        </div>
                    </div>
                </td>

            </tr>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', ['dashboard' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/pages/dashboard/dashboard.blade.php ENDPATH**/ ?>
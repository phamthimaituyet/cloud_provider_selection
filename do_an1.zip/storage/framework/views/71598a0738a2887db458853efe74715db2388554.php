<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('admin.layouts.head_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php
            $page = '';
            if (isset($user)) {
                $page = 'users.index';
            } else if (isset($product)) {
                $page = 'products.index';
            } else if (isset($category)) {
                $page = 'categories.index';
            } else if (isset($criteria)) {
                $page = 'criterias.index';
            } else if (isset($vendor)) {
                $page = 'vendor';
            } else if (isset($dashboard)) {
                $page = 'dashboard';
            }
        ?>
            <?php echo $__env->make('admin.include.head', [
                'page' => $page ?? '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
            <?php echo $__env->make('admin.include.sidebar', [
                'dashboard' => $dashboard ?? '',
                'user' => $user ?? '',
                'category' => $category ?? '',
                'product' => $product ?? '',
                'criteria' => $criteria ?? '',
                'vendor' => $vendor ?? ''
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
                <?php echo $__env->yieldContent('content_header'); ?>
            <!-- /.content-header -->

            <!-- Main content -->
                <?php echo $__env->yieldContent('content'); ?>
            <!-- /.content -->
        </div>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>

   <?php echo $__env->make('admin.layouts.link_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/layouts/index.blade.php ENDPATH**/ ?>
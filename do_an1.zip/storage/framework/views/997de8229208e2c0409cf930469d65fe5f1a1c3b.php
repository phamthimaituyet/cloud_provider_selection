

<?php $__env->startSection('title','Product'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Products</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Products</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('thongbao')): ?>
<div style=" color: green;
            font-size: 18px;
            padding: 15px;">
    <i class="fa fa-check" aria-hidden="true"></i> <b><?php echo e(session('thongbao')); ?></b>
</div>
<?php endif; ?>
<section class="content" style="padding: 30px;">
    <form action="<?php echo e(route('product.new.post')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Create Product</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                        <i class="fas fa-minus"></i></button>
                </div>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="prod_name">
                        <label for="inputName">Product Name</label>
                        <input type="text" name="name" id="inputName" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <div class="parent-price">
                        <div class="price" id="price">
                            <div class="prod_price">
                                <label for="inputType">Type</label>
                                <input type="text" name="type[]" id="inputType" class="form-control">
                            </div>
                            <div class="prod_price">
                                <label for="inputPrice">Price</label>
                                <input type="number" name="price[]" id="inputPrice" class="form-control">
                            </div>
                        </div>
                    </div>
                    <span class="add-product-icon price-icon"><i class="fas fa-plus"></i>Add</span>
                    <span class="remove-product-icon price-icon"><i class="fas fa-minus"></i>Remove</span>
                </div>
                <div class="form-group">
                    <label for="inputDescription">Product Description</label>
                    <textarea id="inputDescription" name="description" class="form-control" rows="4"></textarea>
                </div>
                <div class="form-group">
                    <label for="inputDescription">Product Support</label>
                    <textarea id="inputDescription" name="support" class="form-control" rows="4"></textarea>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select class="form-control select2" name="category_id" style="width: 100%;">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="inputStatus">Vendor</label>
                    <select class="form-control select2" name="vendor_id" style="width: 100%;">
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <div class="row">
            <div class="col-12">
                <a href="#" class="btn btn-secondary">Cancel</a>
                <input type="submit" value="Create new Product" class="btn btn-success float-right">
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/admin/product.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', ['product' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/pages/product/new.blade.php ENDPATH**/ ?>
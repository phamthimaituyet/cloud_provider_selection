<!-- Modal -->
<div class="modal fade" id="reviewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('review', ['id' => $product->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLongTitle">Write review</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if($errors->any()): ?>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-danger mb-3"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="mb-3">
                        <h5>Review rating: </h5>
                        <div class="rating">
                            <input type="radio" name="rating" value="5" id="5"><label
                                for="5">☆</label>
                            <input type="radio" name="rating" value="4" id="4"><label
                                for="4">☆</label>
                            <input type="radio" name="rating" value="3" id="3"><label
                                for="3">☆</label>
                            <input type="radio" name="rating" value="2" id="2"><label
                                for="2">☆</label>
                            <input type="radio" name="rating" value="1" id="1"><label
                                for="1">☆</label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <h5>
                            <label for="message-text" class="col-form-label">Write review:</label>
                        </h5>
                        <textarea class="form-control <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" id="message-text" name="content" style="height: 200px;"></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Send review</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/modal/modal_review.blade.php ENDPATH**/ ?>
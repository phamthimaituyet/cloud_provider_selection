

<?php $__env->startSection('title','User'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">User</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">User</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-body">
    <table id="example2" class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Created_at</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->nameRole($user->role)); ?></td>
                <td><?php echo e($user->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('user.view', ['id' => $user->id])); ?>" class="btn btn-sm btn-primary">
                        <i class="fas fa-user"></i> View
                    </a>
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>">
                        <i class="fas fa-pencil-alt">
                        </i>
                        Edit
                    </a>
                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal"
                        data-id="<?php echo e($user->id); ?>">
                        <i class="fas fa-trash">
                        </i>
                        Delete
                    </button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Delete User</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form action="<?php echo e(route('user.delete')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input id="idUser" type="hidden" name="id" value="">
                <div class="modal-body">
                    <div class="form-group">
                        <p>Are you sure to delete?</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancle</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const buttons = document.querySelectorAll('.btn.btn-danger.btn-sm');
  
    buttons.forEach(button => {
        button.onclick = function() {
            const input = document.querySelector('#idUser');
            input.value = button.getAttribute('data-id');
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', ['user' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/pages/user/user.blade.php ENDPATH**/ ?>
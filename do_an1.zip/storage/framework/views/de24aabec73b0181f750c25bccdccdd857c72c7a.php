

<?php $__env->startSection('title', 'Product detail'); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/detail.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/project_criteria.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="details">
        <?php echo $__env->make('components.prod_detail.prod_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container detailPopup">
            <nav class="pt-36" style="padding-top: 36px;">
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button class="nav-link <?php echo e(app('request')->input('page') || app('request')->input('type') === 'reviews' ? '' : 'active'); ?> border-ct" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home"
                        type="button" role="tab" aria-controls="nav-home" aria-selected="true">Overview</button>
                    <button class="nav-link <?php echo e(app('request')->input('page') || app('request')->input('type') === 'reviews' ? 'active' : ''); ?> border-ct" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile"
                        type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Ratings (<?php echo e($review_stars->count()); ?>)</button>
                    <button class="nav-link border-ct" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact"
                        type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Provider</button>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade <?php echo e(app('request')->input('page') || app('request')->input('type') === 'reviews' ? '' : 'show active'); ?>" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <h1 style="font-weight: 100; color: #0e7f74;">Product Overview</h1>
                    <p class="ellipsis">
                        <?= implode('</br><span class="d-block mt-3"></span>', explode('.', $product->description)) ?>
                    </p>
                    <a target="blank" href="<?php echo e($product->vendor->link); ?>">See details</a>
                    <h1 class="mt-5" style="font-weight: 100; color: #0e7f74;">ISO Certificate</h1>
                    <p class="mt-3">
                        <a target="blank" href="#"><?php echo e($product->certificate); ?></a>
                    </p>
                    <h1 class="mt-5" style="font-weight: 100; color: #0e7f74;">Languages</h1>
                    <p class="mt-3">English</p>
                    <div class="display: none;" style="height: 20%;"></div>
                </div>
                <?php echo $__env->make('components.prod_detail.review', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.prod_detail.provider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.modal.modal_review', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/pages/product/prod_detail.blade.php ENDPATH**/ ?>
<div class="tab-pane fade <?php echo e(app('request')->input('page') || app('request')->input('type') === 'reviews' ? 'show active' : ''); ?>" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
    <h1 style="font-weight: 100; color: #0e7f74;">Review Highlights</h1>
    <div class="d-flex reviews">
        <div class="rating">
            <div class="c-1">5.0</div>
            <div class="c-2 d-flex mx-5">
                <?php echo $__env->make('components.helper.star', ['count_star' => 5, 'class_star' => 'col-5'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <span>
                    <p>Out of 5 (<?php echo e($reviews->count()); ?> Reviews)</p>
                </span>
            </div>
        </div>
        <div class="avg-rating">
            <div>
                <span>Average Rating</span>
            </div>
            <div>
                <?php 
                    $review_stars_clone = clone $review_stars;      // 2 bien bang nhau nhung co dia chi khac nhau => dung clone
                    $review_stars_count = $review_stars_clone->count();
                ?>
                <?php for($i = 0; $i < 5; $i++): ?> 
                <?php 
                    $review_stars_clone = clone $review_stars;
                    $count = $review_stars_clone->where('number_star', 5 - $i)->count();
                ?>
                <div class="d-flex align-items-center">
                    <?php echo $__env->make('components.helper.star', ['count_star' => 5 - $i, 'class_star' => 'star'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="progress me-2">
                        <div class="progress-bar" role="progressbar" 
                            style="background-color: #b7b6b6; width: <?= $review_stars_count != 0 ? floor(($count / $review_stars_count) * 100) : ''  ?>%" 
                            aria-valuenow="<?= $review_stars_count != 0 ? floor(($count / $review_stars_count) * 100) : '' ?>" aria-valuemin="0"
                            aria-valuemax="100"></div>
                    </div>
                    <div>
                        <p><?php echo e($count); ?></p>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
        <div class="comments px-4 mt-2 mb-2">
            <!-- Button trigger modal -->
            <?php if(Auth::check()): ?>
                <div class="px-4 mt-2 mb-2">
                    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#reviewModal">
                        <i class="bi bi-chat-left-text"></i> Write a review
                    </button>
                </div>
                <div class="px-4 mt-2 mb-2">
                    <a href="<?php echo e(route('detailReview', ['id' => $product->id])); ?>">
                        <button type="button" class="btn btn-outline-info">
                            <i class="bi bi-chevron-double-right"></i> Detailed review
                        </button>
                    </a>
                </div>
            <?php else: ?> 
                <a href="<?php echo e(route('login.form')); ?>">
                    <div class="px-4 mt-2 mb-2">
                        <button type="button" class="btn btn-outline-secondary">
                            <i class="bi bi-chat-left-text"></i> Write a review
                        </button>
                    </div>
                    <div class="px-4 mt-2 mb-2">
                        <button type="button" class="btn btn-outline-info">
                            <i class="bi bi-chevron-double-right"></i> Detailed review
                        </button>
                    </div>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <h1 style="font-weight: 100;">Reviews</h1>
    <?php if(count($reviews)): ?>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="parent-inf">
                <div class="d-flex mt-3 align-items-center">
                    <p class="w-100"><b><?php echo e($review->user->name); ?></b></p>
                    <?php if($review->user->id == Auth::user()->id): ?>
                        <div class="edit-update-rev">
                            <a data-bs-toggle="modal" data-bs-target="<?php echo e('#editReviewModal' . $review->id); ?>" class="me-1"><i class="bi bi-pencil-square fs-5"></i></a>
                            <a class="text-danger me-2" data-bs-toggle="modal" data-bs-target=""><i class="bi bi-trash3-fill fs-5"></i></a>
                        </div>
                    <?php endif; ?>
                </div>
                <?php echo $__env->make('components.helper.star', ['count_star' => $review->number_star ?? 0, 'class_star' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.helper.star', ['count_star' => (5 - ($review->number_star ?? 0)), 'class_star' => 'white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div style="margin-top: 10px;"><?php echo e($review->content); ?></div>
                <div><?php echo e($review->created_at->format('d-m-Y')); ?></div>
                <div>
                    <div id="pt1:r1:1:i1:0:rd1:dc_pgls4" class="x1a mt-3 mb-5" style="border-top:1px solid #D6DFE6;"></div>
                </div>
            </div>
            <?php echo $__env->make('components.modal.modal_editReview', ['id' => $review->id, 'review' => $review], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-4">
            <?php echo $reviews->links(); ?>

        </div>
    <?php else: ?>
        <div class="mt-5 py-5 text-center" style="margin-bottom: 100px;">
            <span class="no-inf">This app or service has not been reviewed.</span>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/prod_detail/review.blade.php ENDPATH**/ ?>
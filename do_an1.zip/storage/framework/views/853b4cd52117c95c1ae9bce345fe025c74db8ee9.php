<div id="<?= $id ?>" class="w3-container criteria w3-animate-left">
    <table class="table table-striped projects">
        <thead>
            <tr>
                <th>
                    ID
                </th>
                <th>
                    Weight
                </th>
                <th>
                    Criteria Name
                </th>
                <th>
                    Factor Name
                </th>
                <th>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $condition = $id == 'All' ?  true : $criteria->parent_id == $parent_id?>
            <?php if($condition): ?>
            <tr>
                <td>
                    <p><?php echo e($criteria->id); ?></p>
                </td>
                <td>
                    <p><?php echo e($criteria->weight); ?></p>
                </td>
                <td>
                    <p><?php echo e($criteria->name); ?></p>
                </td>
                <td>
                    <p><?php echo e($criteria->getNameParent($criteria->parent_id)); ?></p>
                </td>
                <td>
                    <a class="btn btn-info btn-sm" href="#">
                        <i class="fas fa-pencil-alt">
                        </i>
                        Edit
                    </a>
                    <a class="btn btn-danger btn-sm" href="#">
                        <i class="fas fa-trash">
                        </i>
                        Delete
                    </a>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/admin/pages/criteria/table_criteria.blade.php ENDPATH**/ ?>
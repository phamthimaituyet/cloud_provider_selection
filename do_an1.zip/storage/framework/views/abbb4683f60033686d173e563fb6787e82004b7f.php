<form action="<?php echo e(route('myProject.updateNote', ['project_id' => $project->id, 'note_id' => $note->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="container my-3 shadow-none p-3 mb-5 bg-light rounded">
        <div class="list-criteria">
            <div class="criteria-elem">
                <div class="">
                    <div class="mb-3">
                        <label for="note" class="col-form-label fw-bold text-danger float-start">Requirements:</label>
                        <textarea class="form-control" id="note" placeholder="Enter note" name="note"><?= isset($note) ? trim($note->note) : ''  ?></textarea>
                        <div id="emailHelp" class="form-text">Please enter requirements, wishes for the project.</div>
                    </div>
                    <div class="mb-3 question-component">
                        <div class="d-flex">
                            <label for="mondai" class="form-label fw-bold text-danger float-start" style="width: 90%;">Questions:</label>
                        </div>
                        <?php $__currentLoopData = $note->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-question mt-3">
                                <input type="text" class="form-control mb-3" name="question[]" id="mondai" placeholder="Enter Question" value="<?php echo e($question->question); ?>" >
                                <select class="form-select" data-placeholder="Choose criteria" name="criteria_id[<?php echo e($key); ?>][]" multiple>
                                    <option></option>
                                    <?php $__currentLoopData = $parent_criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $childs = in_array($parent_criteria->name, ['Cost', 'Capability']) ? [$parent_criteria] : $parent_criteria->children ?>
                                        <optgroup label="<?php echo e($parent_criteria->name); ?>">
                                            <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($child->id); ?>" <?php echo e(in_array($child->id, $question->questionCriterias->pluck('criterias_id')->toArray()) ? 'selected' : ''); ?>><?php echo e($child->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </optgroup>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div id="emailHelp" class="form-text">Create questions and choose the answer criteria for that question.</div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="text-end">
        <button type="submit" class="btn btn-primary mt-2 me-3">Submit</button>
    </div>
</form><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/components/project_criteria/form_edit_criteria.blade.php ENDPATH**/ ?>
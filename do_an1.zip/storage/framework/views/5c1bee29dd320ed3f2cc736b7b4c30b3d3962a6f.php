

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('alert')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('alert')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('login.form')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <h2>Log In</h2>
        <p>
            <label for="email" class="floatLabel">Email</label>
            <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="email" name="email" type="text" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php endif; ?>
        </p>
        <p>
            <label for="password" class="floatLabel">Password</label>
            <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="password" name="password" type="password" value="<?php echo e(old('password')); ?>">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php endif; ?>
        </p>
        <div>
            <button type="submit" class="btn btn-primary btn-block button_acc">Sign in</button>
        </div>
    </form>
    <div class="form_sign_up">
        <h2 style="text-align: center;">Don't have an Account?</h2>
        <button type="button" class="btn btn-outline-secondary mt-3" style="width: 420px;">
            <a href="<?php echo e(route('register.form')); ?>" style="text-decoration: none; color: black; font-size: 1.5rem;">Create
                account</a>
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/auth/login.blade.php ENDPATH**/ ?>
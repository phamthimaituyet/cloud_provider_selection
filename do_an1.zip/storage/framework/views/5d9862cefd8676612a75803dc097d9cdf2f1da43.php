

<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('alerts')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('alerts')); ?>

        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('register.form')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <h2>Create Your Account</h2>
        <p>
            <label for="name" class="floatLabel">Name</label>
            <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" type="text">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php endif; ?>
        </p>
        <p>
            <label for="email" class="floatLabel">Email</label>
            <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="email" name="email" type="text">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php endif; ?>
        </p>
        <p>
            <label for="password" class="floatLabel">Password</label>
            <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="password" name="password" type="password">
            <span>Enter a password longer than 8 characters</span>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php endif; ?>
        </p>
        <p>
            <label for="confirm_password" class="floatLabel">Confirm Password</label>
            <input id="confirm_password" name="confirm_password" type="password">
            <span>Your passwords do not match</span>
        </p>
        <div>
            <button type="submit" class="btn btn-primary btn-block button_acc">Create My Account</button>
        </div>
        <div class="acc_ed">
            <a href="<?php echo e(route('login.form')); ?>" style="text-decoration: none; color: #ce2525e8;">Sign in</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\phamt\Desktop\laravel\do_an1\resources\views/auth/register.blade.php ENDPATH**/ ?>